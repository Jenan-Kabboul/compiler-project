package Ast.Css;

import Ast.ASTNode;

public class ClassSelectorNode extends ASTNode {

    private final String className;

    private final SelectorNode pseudoSelector;

    public ClassSelectorNode(String className,
                             SelectorNode pseudoSelector,
                             int lineNumber) {

        super("ClassSelectorNode", lineNumber);

        this.className = className;
        this.pseudoSelector = pseudoSelector;
    }

    public String getClassName() {
        return className;
    }

    public SelectorNode getPseudoSelector() {
        return pseudoSelector;
    }

    @Override
    public String print(String indent) {

        StringBuilder sb = new StringBuilder();

        sb.append(indent)
                .append("Class Selector: ")
                .append(className)
                .append("\n");

        if (pseudoSelector != null) {
            sb.append(
                    pseudoSelector.print(indent + "  ")
            );
        }

        return sb.toString();
    }
}
