package Ast.Html;
import Ast.ASTNode;

public class HtmlTextNode extends ASTNode {
    private final String text;
    public HtmlTextNode(String text, int lineNumber) {
        super("TextNode", lineNumber);
        this.text = text;
    }
    @Override
    public String print(String indent) {
        return indent + "Text: " + text + " [Line: " + lineNumber + "]\n";
    }
}