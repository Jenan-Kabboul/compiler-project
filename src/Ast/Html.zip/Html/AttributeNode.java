package Ast.Html;

import Ast.ASTNode;

public class AttributeNode extends ASTNode {
    private final String name;
    private final String value;

    public AttributeNode(String name, String value, int lineNumber) {
        super("AttributeNode", lineNumber);
        this.name = name;
        this.value = value;
    }

    public String getName() {
        return name;
    }

    public String getValue() {
        return value;
    }

    @Override
    public String print(String indent) {
        StringBuilder sb = new StringBuilder();
        sb.append(indent);
        sb.append("Attribute: ");
        sb.append(name);

        if (value != null) {
            sb.append("=\"");
            sb.append(value);
            sb.append("\"");
        }

        sb.append(" [Line: ");
        sb.append(lineNumber);
        sb.append("]\n");

        return sb.toString();
    }
}